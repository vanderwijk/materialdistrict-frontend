/**
 * Homepage — TIJDELIJKE PAGINA voor stap 1 (projectfundament).
 * Wordt volledig vervangen in stap 10.
 *
 * Doel nu: bevestigen dat het project draait, fonts geladen zijn,
 * design tokens werken, en dark/light mode te activeren is.
 */

export default function Page() {
  return (
    <div className="container" style={{ padding: '64px 0' }}>
      <span className="eyebrow">Stap 1 — Projectfundament</span>
      <h1 className="page-title" style={{ marginTop: 'var(--space-4)' }}>
        MaterialDistrict
      </h1>
      <p style={{ color: 'var(--text-muted)', maxWidth: '60ch', marginBottom: 'var(--space-8)' }}>
        Project draait. Fonts, tokens en layout zijn actief.
        De echte homepage volgt in stap 10 nadat alle overige secties zijn gebouwd.
      </p>

      <div style={{ display: 'flex', gap: 'var(--space-3)', flexWrap: 'wrap', marginBottom: 'var(--space-8)' }}>
        <button className="btn btn-primary">Primary</button>
        <button className="btn btn-green">Green</button>
        <button className="btn btn-blue">Blue</button>
        <button className="btn btn-outline">Outline</button>
      </div>

      <div style={{ display: 'flex', gap: 'var(--space-2)', flexWrap: 'wrap' }}>
        <span className="ct-tag ct-material">Material</span>
        <span className="ct-tag ct-article">Article</span>
        <span className="ct-tag ct-event">Event</span>
        <span className="ct-tag ct-book">Book</span>
        <span className="ct-tag ct-brand">Brand</span>
        <span className="ct-tag ct-member">Insider</span>
        <span className="insider-badge">Insider</span>
      </div>
    </div>
  )
}
