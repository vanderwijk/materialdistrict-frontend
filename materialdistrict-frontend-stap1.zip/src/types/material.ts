import type { WPPostBase, ListParams } from './shared'

/**
 * Material — voorlopige interface, te bevestigen tegen werkelijke API in sessie 2.
 */
export interface Material extends WPPostBase {
  acf?: {
    brand?: number | { ID: number; post_title: string; post_name: string }
    description?: string
    sustainability?: string
    properties?: Record<string, string | number>
    sample_available?: boolean
    pdf_attachment?: string
    epd_attachment?: string
    video_url?: string
    gallery?: number[]
    /** CSS gradient string voor de card-achtergrond. */
    gradient?: string
    insider_only?: boolean
  }
}

/** Lijst-parameters voor /materials overzicht. */
export interface MaterialsListParams extends ListParams {
  brand?: number
  category?: number
}
