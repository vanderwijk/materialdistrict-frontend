import type { WPPostBase, ListParams } from './shared'

export interface Article extends WPPostBase {
  acf?: {
    author_name?: string
    author_id?: number
    reading_time?: number
    insider_only?: boolean
    related_materials?: number[]
    related_brands?: number[]
  }
}

export interface ArticlesListParams extends ListParams {
  category?: number
  insider_only?: boolean
}
