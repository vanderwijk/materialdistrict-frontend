import type { WPPostBase, ListParams } from './shared'
import type { ManufacturerTier } from '@/lib/config/membership'

export interface Brand extends WPPostBase {
  acf?: {
    tier?: ManufacturerTier
    website?: string
    contact_email?: string
    country?: string
    /** Hoofdkleur van het merk — gebruikt in cards en headers. */
    brand_color?: string
    logo?: number
    legacy?: boolean
    legacy_expires_at?: string
  }
}

export interface BrandsListParams extends ListParams {
  tier?: ManufacturerTier
}
