import type { WPPostBase, ListParams } from './shared'

export interface Event extends WPPostBase {
  acf?: {
    start_date?: string
    end_date?: string
    location?: string
    venue?: string
    registration_url?: string
    gallery?: number[]
    video_url?: string
    free_for_insider?: boolean
  }
}

export interface EventsListParams extends ListParams {
  upcoming?: boolean
}
