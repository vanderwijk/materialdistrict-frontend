import type { WPPostBase, ListParams } from './shared'

export interface Talk extends WPPostBase {
  acf?: {
    speaker_name?: string
    speaker_bio?: string
    speaker_photo?: number
    video_url?: string
    duration_minutes?: number
    event_id?: number
    insider_only?: boolean
  }
}

export type TalksListParams = ListParams
