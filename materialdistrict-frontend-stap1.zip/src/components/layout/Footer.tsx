/**
 * Footer — placeholder voor stap 1 (projectfundament).
 *
 * TODO stap 3 — Gedeelde componenten:
 * - Kolommen (About / Discover / Brands / Membership / Legal)
 * - Newsletter-signup
 * - Social-iconen
 * - Copyright + jaartal
 *
 * Achtergrond #0E2E78 (light) / #060e18 (dark) via .site-footer.
 */
export function Footer() {
  return (
    <footer className="site-footer">
      <div className="container" style={{ padding: '40px 0' }}>
        <span className="eyebrow" style={{ color: 'rgba(255,255,255,0.6)' }}>
          Footer — TODO stap 3
        </span>
      </div>
    </footer>
  )
}
