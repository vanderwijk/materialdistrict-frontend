/**
 * Header — placeholder voor stap 1 (projectfundament).
 *
 * TODO stap 3 — Gedeelde componenten:
 * - Logo (DM Serif Display, .logo-text klasse)
 * - Hoofdnavigatie (Materials / Brands / Articles / Talks / Events / Books)
 * - Zoekbalk
 * - Cart-icoon (WooCommerce sessie)
 * - Gebruikersmenu (login/register/profile)
 * - Dark mode toggle
 * - Mobile drawer
 *
 * Hoogtes via CSS-tokens: 62 / 56 / 54 px (desktop / tablet / mobile).
 */
export function Header() {
  return (
    <header className="site-header">
      <div className="container" style={{ height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <span className="logo-text">MaterialDistrict</span>
        <span className="eyebrow">Header — TODO stap 3</span>
      </div>
    </header>
  )
}
